# WinRar Bypass

A Simple Windows Script to Bypass WinRar Activation 


![Logo](https://i.ibb.co/fdC4kSv/image.png)


## Usage

Automatic:
- run the *activate.cmd* file as administrator (right-click  & choose 'run as administrator')

(or)

Manual :
- Copy the rarreg.key file to your winRar's installation path



## ⚠ Note
This script is for educational purposes only. I want to make it clear that I do not possess any warranty or license for this software. I strongly encourage you to purchase a legitimate copy of the software directly from the company.
